import psycopg2
from psycopg2 import Error


try:
    # connection to database
    print("Connecting...")


    def get_connected():
        connection = psycopg2.connect(
                    dbname=" ",
                    user=" ",
                    password=" ",
                    host=" ",
                    port=" ")
        return connection

    connection = get_connected()

    # creates cursor
    cursor = connection.cursor()

    # prints postgresql details - DO NOT ALTER OR DELETE
    print("PostgreSQL server information:")
    print(connection.get_dsn_parameters(), "\n")

    # executes query for database version - DO NOT ALTER OR DELETE
    cursor.execute("SELECT version();")

    # fetches result and prints database information - DO NOT ALTER OR DELETE
    record = cursor.fetchone()
    print("Connection successful. You are connected to - ", record, "\n")

# handles errors and prints them to the console - DO NOT ALTER OR DELETE

except (Exception, Error) as error:
    print("Error while connecting to PostgreSQL DB", error)

finally:
    if (connection):
        cursor.close()
        connection.close()
        print("DB connection is closed.")



